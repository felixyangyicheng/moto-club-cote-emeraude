self.assetsManifest = {
  "version": "OMCWMoju",
  "assets": [
    {
      "hash": "sha256-LWFY72hQu+5/7Y5hmbNic3UbPGLoMBFS+OZUrYFz7L4=",
      "url": "Capybara.styles.css"
    },
    {
      "hash": "sha256-+r2Sg5Y3UnJc+gPuwfvHpR2THGSurb59suI7cz3IS0U=",
      "url": "README.md"
    },
    {
      "hash": "sha256-J9TSWXigooGb+fEnncVdFuj6SELM47vT/6atUOfWdVA=",
      "url": "_content/BlazorPro.Spinkit/spinkit.min.css"
    },
    {
      "hash": "sha256-/p5aH5Ive3UyD+SSygCTrCEe/z3Tj+j/+XmUSbfy8Q4=",
      "url": "_content/BlazorTypewriter/styles.css"
    },
    {
      "hash": "sha256-ChowImWYEpmm/VwKK1CMo8KsSd3CxtllZkPKYhW0ZdA=",
      "url": "_content/BootstrapBlazor.WebAPI/BootstrapBlazor.WebAPI.avp4en0ob8.bundle.scp.css"
    },
    {
      "hash": "sha256-ztFVRzijwfExHBbsqOF8uNDhC/4fOo3OFNV4/jHPE70=",
      "url": "_content/BootstrapBlazor.WebAPI/Capture.razor.js"
    },
    {
      "hash": "sha256-gXjmx83bztTb8VhjwhpW7QwrC3eNfb4J/JBcVq496xs=",
      "url": "_content/BootstrapBlazor.WebAPI/WebSerial.razor.js"
    },
    {
      "hash": "sha256-+r9YEQ55uZbGopcenAUqLRfoVPbJculnfpb72mRkJ1c=",
      "url": "_content/BootstrapBlazor.WebAPI/WebSpeech.razor.js"
    },
    {
      "hash": "sha256-C9JY/TjoL5nLc7S2BkyjNwRgeh9BgRt5hMfh7xSZ0g8=",
      "url": "_content/BootstrapBlazor.WebAPI/app.js"
    },
    {
      "hash": "sha256-8xHNuNGBckGCu5/eLirzWgEAHWZUvWgGU9FOrgUiCK4=",
      "url": "_content/BootstrapBlazor.WebAPI/download.js"
    },
    {
      "hash": "sha256-dH5cdBX8GhPqyah3upBzt3j/tBsPZb7kdv1kmB7mG7c=",
      "url": "_content/BootstrapBlazor.WebAPI/zxing.min.js"
    },
    {
      "hash": "sha256-htO3WNQdRMXgi6cjFPbN1PYM6haOhbGZaqvdsyyRPyU=",
      "url": "_content/BootstrapBlazor/Components/Anchor/Anchor.razor.js"
    },
    {
      "hash": "sha256-GL7SCK7ovInyIxuonh5Q0Wik4pd+POjN7tSr1PwONto=",
      "url": "_content/BootstrapBlazor/Components/AnchorLink/AnchorLink.razor.js"
    },
    {
      "hash": "sha256-BRQYTNWfl3Rh3L0lWffNK8BuRnTwHnEejHzVH5xHHok=",
      "url": "_content/BootstrapBlazor/Components/AutoComplete/AutoComplete.razor.js"
    },
    {
      "hash": "sha256-HZ2YZ9NirV3xnMwuwkJP8EGjiU4OuQjunUtEOjRuK2s=",
      "url": "_content/BootstrapBlazor/Components/Button/Button.razor.js"
    },
    {
      "hash": "sha256-4Qtzmn2dKFVABOkjEwaiUduG8MlzjSdXScSpljL1Ewo=",
      "url": "_content/BootstrapBlazor/Components/Button/DialButton.razor.js"
    },
    {
      "hash": "sha256-ZwKuHGCH/6IoyE2zR7kQz/fnHSYVNZW8ZhnDTSchz/E=",
      "url": "_content/BootstrapBlazor/Components/Button/PopConfirmButton.razor.js"
    },
    {
      "hash": "sha256-BDYVmAEbSLz0RYyOxZJ7VDs+X05eCerANVhT9GeeXQo=",
      "url": "_content/BootstrapBlazor/Components/Button/PopConfirmButtonContent.razor.js"
    },
    {
      "hash": "sha256-4ol0Qt0Xae4Op72pyLwXbkeYXXDK5i3NnKSGhg99gHQ=",
      "url": "_content/BootstrapBlazor/Components/Button/SlideButton.razor.js"
    },
    {
      "hash": "sha256-iwqJyKP3FGCI0SHRZSNa9rjyEgZWqJeFf1Hfsi5J8PI=",
      "url": "_content/BootstrapBlazor/Components/Camera/Camera.razor.js"
    },
    {
      "hash": "sha256-sUjmdfUShgX0Pf9AWLQkmriPqqpIpseefSuaHpEQhAA=",
      "url": "_content/BootstrapBlazor/Components/Captcha/Captcha.razor.js"
    },
    {
      "hash": "sha256-1bo8x5dmNCpN3YjG7xhI/jfz2NMTGTph/syka2RXjeI=",
      "url": "_content/BootstrapBlazor/Components/Card/Card.razor.js"
    },
    {
      "hash": "sha256-8XAQLTsAFoqbfX39gJ4YiletYmrXKDxVqxWmzmeBYzU=",
      "url": "_content/BootstrapBlazor/Components/Carousel/Carousel.razor.js"
    },
    {
      "hash": "sha256-32seQ0TAjj8U7N5VwfsJWvsg69blbfN4l2GB1BlWol4=",
      "url": "_content/BootstrapBlazor/Components/Checkbox/Checkbox.razor.js"
    },
    {
      "hash": "sha256-4MyqDmOhlXhzRUBy6yjCWEz3aHuWs6mR/Lyoah935+A=",
      "url": "_content/BootstrapBlazor/Components/ClockPicker/ClockPicker.razor.js"
    },
    {
      "hash": "sha256-kYgpfMNog3y1V/r7AIhez3px55S03BC7GMeBLES+hZk=",
      "url": "_content/BootstrapBlazor/Components/ColorPicker/ColorPicker.razor.js"
    },
    {
      "hash": "sha256-Gph+9H1SEVwWXdYRweJi2NT97d2+Wbs8VHo6+FQI8Wc=",
      "url": "_content/BootstrapBlazor/Components/Console/Console.razor.js"
    },
    {
      "hash": "sha256-68dfxXkyDdNYahiL5EJ6Jb0n30vvIqqQXWmrVwH9Tls=",
      "url": "_content/BootstrapBlazor/Components/ContextMenu/ContextMenu.razor.js"
    },
    {
      "hash": "sha256-zg0e561G/51ggZoBmFFagPGdNhiik5ni2AvSAcstThQ=",
      "url": "_content/BootstrapBlazor/Components/CountUp/CountUp.razor.js"
    },
    {
      "hash": "sha256-W3s9agXMuTxhwHWaNeXt/j+Xm8DqYCrMtzBPPhnvGGM=",
      "url": "_content/BootstrapBlazor/Components/DateTimePicker/DateTimePicker.razor.js"
    },
    {
      "hash": "sha256-BGouVwnHuwk15IfNyy8qENO2jPuVCEiJQYawpqwqTew=",
      "url": "_content/BootstrapBlazor/Components/Dialog/EditDialog.razor.js"
    },
    {
      "hash": "sha256-198KlCIQpqM48uBeRJ99Jjv2vSdykU8oTk387fj0+FQ=",
      "url": "_content/BootstrapBlazor/Components/Dialog/IconDialog.razor.js"
    },
    {
      "hash": "sha256-ZQ2AOq0DhibB27+78bgtrpiK74PY4cOe1cAJ/sma6OM=",
      "url": "_content/BootstrapBlazor/Components/Drawer/Drawer.razor.js"
    },
    {
      "hash": "sha256-66HDv3RxzYl7RH4wvAxkD6bABLfLwcoeMp5GHHB1vT0=",
      "url": "_content/BootstrapBlazor/Components/Dropdown/Dropdown.razor.js"
    },
    {
      "hash": "sha256-jZ+GUXIpYH8QQX3323MediAP3oRUsf3Eh3NH6if5f08=",
      "url": "_content/BootstrapBlazor/Components/DropdownWidget/DropdownWidget.razor.js"
    },
    {
      "hash": "sha256-388QEBImGVk5d4paIykvUp3hbbhGWx/R5M68vzd9TY4=",
      "url": "_content/BootstrapBlazor/Components/Filters/MultiFilter.razor.js"
    },
    {
      "hash": "sha256-aDxmpjJLHMxvocSFTK4MO/M1BdpuYeyUPDrBvyYhZl8=",
      "url": "_content/BootstrapBlazor/Components/Filters/TableFilter.razor.js"
    },
    {
      "hash": "sha256-FRnyOjiiMb8hkS+IDdQIEK4Emp8UxrB/e6moI7lQ57w=",
      "url": "_content/BootstrapBlazor/Components/FlipClock/FlipClock.razor.js"
    },
    {
      "hash": "sha256-KP2ZybrTYbOo23JzEKtSvUb3CA75KibDNCSk7FHrc1c=",
      "url": "_content/BootstrapBlazor/Components/GoTop/GoTop.razor.js"
    },
    {
      "hash": "sha256-PTRAabR/9M4M8nYNQr3Nj0VnyUJcKP1q/KOezBph/Kw=",
      "url": "_content/BootstrapBlazor/Components/Handwritten/Handwritten.razor.js"
    },
    {
      "hash": "sha256-89kG09OufRv4zpQPpOYrIXanp39FwObqAbiGED37rH8=",
      "url": "_content/BootstrapBlazor/Components/IFrame/IFrame.razor.js"
    },
    {
      "hash": "sha256-MZwxB6I4gKIXLPP2wQ5qjuvUR9Oa+/wAvVmFEsVlJAQ=",
      "url": "_content/BootstrapBlazor/Components/ImagePreviewer/ImagePreviewer.razor.js"
    },
    {
      "hash": "sha256-z+O4hACyfxi6E5j2j/jjPw+I76PRTCUKwwiyFOKhFmE=",
      "url": "_content/BootstrapBlazor/Components/ImageViewer/ImageViewer.razor.js"
    },
    {
      "hash": "sha256-qrpLgaXictKBoO5C7sMyneiafCFvj4uPWZUKj6khAZQ=",
      "url": "_content/BootstrapBlazor/Components/Input/BootstrapInput.razor.js"
    },
    {
      "hash": "sha256-M3sbt7eh9f4oNh85WSaLX0RkmSVs7xvST0dKbqQoloA=",
      "url": "_content/BootstrapBlazor/Components/IntersectionObserver/IntersectionObserver.razor.js"
    },
    {
      "hash": "sha256-sOQaztXIAYbzPR+/FhCQrzfDn5sEBTu6PvvPWnTdtEk=",
      "url": "_content/BootstrapBlazor/Components/IpAddress/IpAddress.razor.js"
    },
    {
      "hash": "sha256-REJ1dEgkRJoFeBjkaIFaVXHrFDxLvWelIql1x1Iaus0=",
      "url": "_content/BootstrapBlazor/Components/Layout/Layout.razor.js"
    },
    {
      "hash": "sha256-6ZQm1l0ANYxSyVO+vEa33P7pNYwa/NDO3Cg7R30jPjs=",
      "url": "_content/BootstrapBlazor/Components/Mask/Mask.razor.js"
    },
    {
      "hash": "sha256-M7WdCNKt6aF2PQ+WCGd1kQLnPpiOqL58cv/6HVlCIlc=",
      "url": "_content/BootstrapBlazor/Components/Menu/Menu.razor.js"
    },
    {
      "hash": "sha256-ETOSZDWzuYghlUGiP8oTo+XAZLEU0oWWBiNIbcRWf+c=",
      "url": "_content/BootstrapBlazor/Components/Message/Message.razor.js"
    },
    {
      "hash": "sha256-VUBXWiXHm5LZHvEmJWQqPbWUZgq+iyAdknOPdsNs4hE=",
      "url": "_content/BootstrapBlazor/Components/Modal/Modal.razor.js"
    },
    {
      "hash": "sha256-hWfMjuHccfLk7Pp3Ptn0SmL0H+6YEmxsNRnDdDYx6Dc=",
      "url": "_content/BootstrapBlazor/Components/Modal/ModalDialog.razor.js"
    },
    {
      "hash": "sha256-Eudt1iHwMPHkiCMS4zWcCElCvycDpdC5WApbMylmu+Q=",
      "url": "_content/BootstrapBlazor/Components/Popover/Popover.razor.js"
    },
    {
      "hash": "sha256-XU+TGxNojUWbd7obyIN0loHgFlRqr7cTPuHB9hYFiYE=",
      "url": "_content/BootstrapBlazor/Components/Print/PrintButton.razor.js"
    },
    {
      "hash": "sha256-dqQV42Wnpy3VYUJCbXC910kNrAtdlhbXYhrZ9eFxVU0=",
      "url": "_content/BootstrapBlazor/Components/Reconnector/ReconnectorContent.razor.js"
    },
    {
      "hash": "sha256-XegJYJ8DaOKK9qE57v9pAjrkoA1rRKXwHowtmNzpcw4=",
      "url": "_content/BootstrapBlazor/Components/RibbonTab/RibbonTab.razor.js"
    },
    {
      "hash": "sha256-VEkh8t30smhBkrqKu73sWk1dPhyrOdBHFffg8/1DuLw=",
      "url": "_content/BootstrapBlazor/Components/Row/Row.razor.js"
    },
    {
      "hash": "sha256-2nR/i2TUkWH34GuThFfJl/kLHY87Qq4/yWcKgoRJiCA=",
      "url": "_content/BootstrapBlazor/Components/Segmented/Segmented.razor.js"
    },
    {
      "hash": "sha256-ALR1QWzT0gZcB3pFCFy3C4ZV11hmEh175GVndmZTDY0=",
      "url": "_content/BootstrapBlazor/Components/Select/MultiSelect.razor.js"
    },
    {
      "hash": "sha256-CyFfgaN6nrhayAfFQFlZdTn26ZG1PbEJOnmYmqxH8Io=",
      "url": "_content/BootstrapBlazor/Components/Select/Select.razor.js"
    },
    {
      "hash": "sha256-UMF75s1uQS6oufa+mVFRgSUKfItf5/fFQAmnE256wSc=",
      "url": "_content/BootstrapBlazor/Components/Select/SelectObject.razor.js"
    },
    {
      "hash": "sha256-Vqj9+bZdmfQLjF8vRe1I6YsTpeWeLdFh3lEg/LYSsHU=",
      "url": "_content/BootstrapBlazor/Components/Select/SelectTable.razor.js"
    },
    {
      "hash": "sha256-SuCpOr/Hyw5ZVTSdSZsT2Fi5XqwZuOrood3+PX+cDlI=",
      "url": "_content/BootstrapBlazor/Components/Select/SelectTree.razor.js"
    },
    {
      "hash": "sha256-vPctFoEv8hRMcsBR68YmZpjJCZj3yucUmVnZsNS1Zak=",
      "url": "_content/BootstrapBlazor/Components/Split/Split.razor.js"
    },
    {
      "hash": "sha256-VIo4I0pTlxcC/oYl4/DPS1RjVM5dUhghBZTSQqEo7X4=",
      "url": "_content/BootstrapBlazor/Components/Tab/Tab.razor.js"
    },
    {
      "hash": "sha256-ucpEUIoREP7nDmfdraTERohCig4R8qPlMC+bLcQDp+o=",
      "url": "_content/BootstrapBlazor/Components/Table/Table.razor.js"
    },
    {
      "hash": "sha256-pAE2ebc8DecQnHVPCrP9XC/elIUf/JOyylAsPlx6odU=",
      "url": "_content/BootstrapBlazor/Components/Textarea/Textarea.razor.js"
    },
    {
      "hash": "sha256-FjmRYzv9D86eyciXwBBuh6NNDSQ/72Tz00TTrt12I4Q=",
      "url": "_content/BootstrapBlazor/Components/ThemeProvider/ThemeProvider.razor.js"
    },
    {
      "hash": "sha256-Xv9VeEJU3iH/cTHwlJC1WNFVB5sMy4VPIiWIG29S9so=",
      "url": "_content/BootstrapBlazor/Components/TimePicker/TimePickerCell.razor.js"
    },
    {
      "hash": "sha256-aE++lx5OglfW01D/fzvMZ8I7xZ2UOV4pfnel5pCZz4c=",
      "url": "_content/BootstrapBlazor/Components/Toast/Toast.razor.js"
    },
    {
      "hash": "sha256-0CLvuZG1BiCzjbzpihihYioRi6wfEPMSB2Pw7T2SsXU=",
      "url": "_content/BootstrapBlazor/Components/Tooltip/Tooltip.razor.js"
    },
    {
      "hash": "sha256-C4N2MVHwd1i1wzFQaohVvs1KSo8pF90alFx4UjjokbQ=",
      "url": "_content/BootstrapBlazor/Components/Transition/Transition.razor.js"
    },
    {
      "hash": "sha256-e/Y+QGAwXn/SxMsbqQjFpAAyen0mTAXyITBnCZbIUiA=",
      "url": "_content/BootstrapBlazor/Components/TreeView/TreeView.razor.js"
    },
    {
      "hash": "sha256-ysuHyICcivSlw4CZdWYDyVDVdz93/4xRJ3ETjy61/Mo=",
      "url": "_content/BootstrapBlazor/Components/ValidateForm/ValidateForm.razor.js"
    },
    {
      "hash": "sha256-f4F98yzH70eFH9LkFrMWTfa81s9dOByrOKi69rX0ubU=",
      "url": "_content/BootstrapBlazor/Components/Waterfall/Waterfall.razor.js"
    },
    {
      "hash": "sha256-ph4SMxQYi9BFMyAAjgG0u7ZlvuCQOfTL2b70TeQQzmc=",
      "url": "_content/BootstrapBlazor/css/animate.min.css"
    },
    {
      "hash": "sha256-/AZ/1wOrnRf/KPTY/U/I/SzKFjWPcHWOoXv8NtNOVkk=",
      "url": "_content/BootstrapBlazor/css/bootstrap.blazor.bundle.min.css"
    },
    {
      "hash": "sha256-islk3y0mbyBEwzcNIVmMTOj/FMKXczgiHiTDS+qOt6c=",
      "url": "_content/BootstrapBlazor/css/bootstrap.blazor.bundle.rtl.min.css"
    },
    {
      "hash": "sha256-sKIQRfQriISuQ9l/44b1zHfQniGXJhGonVtB2LlSuIs=",
      "url": "_content/BootstrapBlazor/css/bootstrap.min.css"
    },
    {
      "hash": "sha256-rI1w2GDxZPCr77bpZIGQ8mUvMVtEr+gBtahl5RIPJpA=",
      "url": "_content/BootstrapBlazor/css/bootstrap.rtl.min.css"
    },
    {
      "hash": "sha256-l5VqzlJGrj4ZTHqhZA4OO6fi4zS9YtmR4p0+bNX36xs=",
      "url": "_content/BootstrapBlazor/css/bootstrapblazor.min.css"
    },
    {
      "hash": "sha256-gReSj9U32NupXufhAVzFDuVjeuTzKj5CN8x0DSP8I4g=",
      "url": "_content/BootstrapBlazor/css/motronic.min.css"
    },
    {
      "hash": "sha256-SFhWIVDuA8ysxQHAnbmOSCCEvhLgBhYDRwW2IHstnyI=",
      "url": "_content/BootstrapBlazor/css/nano.min.css"
    },
    {
      "hash": "sha256-EOnZjqGRXA4rzElTgr8kVoPBHDjKODtOjmrpACC0KwE=",
      "url": "_content/BootstrapBlazor/css/rtl.css"
    },
    {
      "hash": "sha256-tqFZk9Qcu3cs/X9qcRhFiNhG67b7+v3aRjOGQfDkraw=",
      "url": "_content/BootstrapBlazor/css/sweetalert2.css"
    },
    {
      "hash": "sha256-6zfk2L8R3wCgRbZzpkEi7UYC2bc6fYGIgFfNeqyOWnQ=",
      "url": "_content/BootstrapBlazor/js/bootstrap.blazor.bundle.min.js"
    },
    {
      "hash": "sha256-2Iav7zCT56knFN1EYEK3m+/8EOtafYFUjM0WdgEZDV8=",
      "url": "_content/BootstrapBlazor/lib/countUp/countUp.min.js"
    },
    {
      "hash": "sha256-fUilFzk/6WAkvC/KR7tjfz/YNoHjiVuyVUrTaZmGJ5Q=",
      "url": "_content/BootstrapBlazor/lib/floating-ui/floating-ui.core.esm.js"
    },
    {
      "hash": "sha256-xecq2v17J+VtX54x31t3D+bcwNujCN11+qIjG/FoxNw=",
      "url": "_content/BootstrapBlazor/lib/floating-ui/floating-ui.dom.esm.js"
    },
    {
      "hash": "sha256-3cXssKDqC/WrkaToeBMARkSjS/rw3Vm8XYViNAlRTfI=",
      "url": "_content/BootstrapBlazor/lib/pickr/pickr.es5.min.js"
    },
    {
      "hash": "sha256-bFWERRiV/UzWw8B/L6lSvFarRyLr47hnZgGKefD+W8I=",
      "url": "_content/BootstrapBlazor/modules/ajax.js"
    },
    {
      "hash": "sha256-o2hOJk0/Cp7BoUFeEMFsZa5V1leXXhEp+xWlsh1g4aM=",
      "url": "_content/BootstrapBlazor/modules/autoredirect.js"
    },
    {
      "hash": "sha256-HKmlovtdRGvGrSc8kPciCik2f/T2BEZmzE3WGF4Rx/o=",
      "url": "_content/BootstrapBlazor/modules/base-popover.js"
    },
    {
      "hash": "sha256-TPmKzKOGtosGTncVkH6OBahe16L98e+Wqh7VII1ZLqw=",
      "url": "_content/BootstrapBlazor/modules/browser.js"
    },
    {
      "hash": "sha256-v6jqf5YzXIjyCywu9BTRYvkmvT81gF1YoHHpeDlNlLU=",
      "url": "_content/BootstrapBlazor/modules/bt.js"
    },
    {
      "hash": "sha256-fFV0T85RxLUYVFsrFUolD01ajQ34PHEFgRhZlmHk5Ls=",
      "url": "_content/BootstrapBlazor/modules/client.js"
    },
    {
      "hash": "sha256-chNnzps1CfYj2GcDohJvXDqDYdVlS/3d5fCU+eDc260=",
      "url": "_content/BootstrapBlazor/modules/data.js"
    },
    {
      "hash": "sha256-V81+Ghm5rtT4otHmxQqz4N/ol8/EVNj5D9fRw58qkts=",
      "url": "_content/BootstrapBlazor/modules/debounce.js"
    },
    {
      "hash": "sha256-98drtBU0XWf1XkxeLEW89fS2/8BvO3mkfh4/NExOwrU=",
      "url": "_content/BootstrapBlazor/modules/download.js"
    },
    {
      "hash": "sha256-wqPHVpm+81bwckRGy0ssSpdznBh26zM0f60qspY3Chw=",
      "url": "_content/BootstrapBlazor/modules/drag.js"
    },
    {
      "hash": "sha256-EF2noyS6PsNO8cAjRW/sExKdT6GvcRzkFpltTT1RteQ=",
      "url": "_content/BootstrapBlazor/modules/event-handler.js"
    },
    {
      "hash": "sha256-jNGoHWS4z9nU1+ZFxRbnAbxVOH9n1AsrcjpSwTz1v6Q=",
      "url": "_content/BootstrapBlazor/modules/eye-dropper.js"
    },
    {
      "hash": "sha256-eWScavK6jdOujg3wYZDeq1MvV3vobkuxdZcAJCvH9Tg=",
      "url": "_content/BootstrapBlazor/modules/floating-ui.js"
    },
    {
      "hash": "sha256-cq9Dbmdek+pREehzoIE19cQErvQhlnErC4OBeiD2rls=",
      "url": "_content/BootstrapBlazor/modules/fullscreen.js"
    },
    {
      "hash": "sha256-fYA8ufqKYufKlQK9qfo3a1cePMmTMsbks+a/qaUtFpY=",
      "url": "_content/BootstrapBlazor/modules/geo.js"
    },
    {
      "hash": "sha256-QHrnyJ2eKZutURIG7mPPBXGUj0tzQq1l9aLd+JCp0m4=",
      "url": "_content/BootstrapBlazor/modules/hub.js"
    },
    {
      "hash": "sha256-u3GMxEUvnHQHIg/TtVkGhoYAip304zkYqUop9FqL264=",
      "url": "_content/BootstrapBlazor/modules/input.js"
    },
    {
      "hash": "sha256-L52UFUIUQa3xr4RZp3Br/tSb717Mtigb7DTnLvDS5mU=",
      "url": "_content/BootstrapBlazor/modules/noti.js"
    },
    {
      "hash": "sha256-oGKBW5HNqTji82SvD0tv76hZ7wYB91NN9ZwP0vUKw0k=",
      "url": "_content/BootstrapBlazor/modules/recognition.js"
    },
    {
      "hash": "sha256-Pkg94hmiLoctbV1029tZxmwnuh/n5y7OsPzuB5oM3vQ=",
      "url": "_content/BootstrapBlazor/modules/responsive.js"
    },
    {
      "hash": "sha256-0CbywDqhmnxk6e7Lkc+s+cgIq1IqCKvXBSwxog+kEsY=",
      "url": "_content/BootstrapBlazor/modules/serial.js"
    },
    {
      "hash": "sha256-qB8Fxn/JxfsYcFN8sTLeGoqRCX4tL5ssqoZ9TRwUQPo=",
      "url": "_content/BootstrapBlazor/modules/synthesis.js"
    },
    {
      "hash": "sha256-N8njNhpNZbpWl2pkjuYeTWQCkuHVE3SPjnhweZH1nv8=",
      "url": "_content/BootstrapBlazor/modules/upload.js"
    },
    {
      "hash": "sha256-zdraB1VO+oDeO7mPe1P45wMC+xJXyb3S0n1ZBYwwthE=",
      "url": "_content/BootstrapBlazor/modules/utility.js"
    },
    {
      "hash": "sha256-nbkNAt/PJS3ClFXypWXvoa0//KxLljPeqAHQ790Xdhg=",
      "url": "_content/BootstrapBlazor/modules/validate.js"
    },
    {
      "hash": "sha256-O+jd684VncNpEjR622OBeaibr5+aZjw9mMDFShWcOFw=",
      "url": "_content/BootstrapBlazor/modules/viewer.js"
    },
    {
      "hash": "sha256-ZSJicRfSsO+B1xWmpXJ7ou81EIg418GnukAMFJRn3Bc=",
      "url": "_content/MudBlazor/MudBlazor.min.css"
    },
    {
      "hash": "sha256-EZNMO/azgG7IPa1IlFGwWmLhT64HPPCxhE0H6t+BOiM=",
      "url": "_content/MudBlazor/MudBlazor.min.js"
    },
    {
      "hash": "sha256-oQvSWR3JOlm+ohv4ovIcQkgLnBzz+q8hRIwWOFZCd9I=",
      "url": "_framework/BlazorComponentUtilities.jrk97nw8r4.wasm"
    },
    {
      "hash": "sha256-IQlANxXKe2MbUR2gXAqzX+z6JMbE7zAfl7+HV2shzGc=",
      "url": "_framework/BlazorPro.Spinkit.xgohbmf257.wasm"
    },
    {
      "hash": "sha256-ZbittBGHjmbJEXJwXImlPlYJ78EDAcRA3FWgjO8zuXw=",
      "url": "_framework/BlazorTypewriter.nd3iuu5wq6.wasm"
    },
    {
      "hash": "sha256-wUWuOXjm0yd4EGJHfwNhBCEd0UCkrhgcsZV7scfl/6o=",
      "url": "_framework/BootstrapBlazor.WebAPI.1cl339xwip.wasm"
    },
    {
      "hash": "sha256-rzSKLQGQBDtsClZ40cBIUYqIrwFN4y9umpfPwUtEm/g=",
      "url": "_framework/BootstrapBlazor.rt49smg8p8.wasm"
    },
    {
      "hash": "sha256-LkgR2Ac+vgfPwqyWWWfjY5VcfGHgVjX1F6etI+e+kLA=",
      "url": "_framework/Capybara.2smy8is3lh.wasm"
    },
    {
      "hash": "sha256-oPg1uUDkkldyCub2SMHh8wQpAfPY4Y1o52G6YtaMcFc=",
      "url": "_framework/Microsoft.AspNetCore.Authorization.slxevey7kd.wasm"
    },
    {
      "hash": "sha256-PwzAM00p2oWj2JlPOBeeYxpdTmSnNI+fi2LdHzgN55M=",
      "url": "_framework/Microsoft.AspNetCore.Components.Authorization.53d64ujug7.wasm"
    },
    {
      "hash": "sha256-MRCXMeMGIVN2kR25xZjU/Nc9gHzQXLnTMF8IODeI85I=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.l7mve4be2c.wasm"
    },
    {
      "hash": "sha256-Dye0Aj/HffTBihjqcXnnL+N56fPnrawFMbDu6BUJ3+4=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.xc2k4rwr9z.wasm"
    },
    {
      "hash": "sha256-1l3ZrKMldyo3L1X3atBMxb3w1RgcBQD+XWdZ2OsZWjc=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.q7odepxf4d.wasm"
    },
    {
      "hash": "sha256-vRbV4NEnZPSubNh5RyG5zlE7HUUdW/E+5gfg9IYe4lU=",
      "url": "_framework/Microsoft.AspNetCore.Components.ftqip21utc.wasm"
    },
    {
      "hash": "sha256-AH1v+kDPbone1a2Uhs2EYvzbkEkxWfwLuPgetuVZVTA=",
      "url": "_framework/Microsoft.AspNetCore.Metadata.kb2pnhxx9n.wasm"
    },
    {
      "hash": "sha256-VPbljs3u8pKFVYX32mxuJaXjjDYCANJ4aCgqc1SyyDE=",
      "url": "_framework/Microsoft.CSharp.sg5kddjg2s.wasm"
    },
    {
      "hash": "sha256-ZPauYUW8vD1fWI68KhNY6HHOJoA7Y7ZYEpKmYG17pRY=",
      "url": "_framework/Microsoft.Extensions.Caching.Abstractions.c2d1axx6sr.wasm"
    },
    {
      "hash": "sha256-xbCfIauXq50O/tol8Dic11yqVh/gEZh6LtDTtXPW1e8=",
      "url": "_framework/Microsoft.Extensions.Caching.Memory.5wo739drpw.wasm"
    },
    {
      "hash": "sha256-VNCoi3v7IH86q1ERmXaBcXN5bvsQURHkrGtMJbCPg20=",
      "url": "_framework/Microsoft.Extensions.Configuration.83yncijqk4.wasm"
    },
    {
      "hash": "sha256-NHz0Uj9a1O18XsfhzjHljqKMfrdoeqTzPYy5Q94sEnU=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.suu4z51ngl.wasm"
    },
    {
      "hash": "sha256-SGS2KqWoX5QrT7Gji7nGkCc3ufCPHvjA42SuBmzBf90=",
      "url": "_framework/Microsoft.Extensions.Configuration.Binder.49krxlpsiz.wasm"
    },
    {
      "hash": "sha256-leW12YOYNcJ2Q/IN+5382Ew4inBadzvN3raWZkFZSk8=",
      "url": "_framework/Microsoft.Extensions.Configuration.FileExtensions.5cyvm87bgk.wasm"
    },
    {
      "hash": "sha256-zaE9G/LDtWjW83jNR1qBNmdJ/8ZTrch5YVWb1abG0EE=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.3sg1nz70mo.wasm"
    },
    {
      "hash": "sha256-Y5IJJUghAC2Usdz2CUqlNIU/iUQHuXlY84XuZ5k9XKk=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.lmr3zfedv6.wasm"
    },
    {
      "hash": "sha256-B7mY4Cop/Md/fK1orLh65qOtPeVjxGJu+VZid2z/Q5k=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.z10nhqoqkw.wasm"
    },
    {
      "hash": "sha256-udXn/0bcTx5GOwMKP55YP0igfwTAXrKVyOb0HNt8BnY=",
      "url": "_framework/Microsoft.Extensions.Diagnostics.9wjofzsnko.wasm"
    },
    {
      "hash": "sha256-B1UXkgFSE2agrNMSEivyMuMolUfRQneQ2kdvIbH5l2s=",
      "url": "_framework/Microsoft.Extensions.Diagnostics.Abstractions.lxk837v1en.wasm"
    },
    {
      "hash": "sha256-sY8AMesdFrsZOQC+MwsbD98MFGRiQO3ZYRlIwK/2yUw=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Abstractions.xs2yxj6szx.wasm"
    },
    {
      "hash": "sha256-CIhwnFA9kV2zsgqJN2UwCRFdGcV5u9yvreszS4lRuLo=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Physical.o8ot4h3jfx.wasm"
    },
    {
      "hash": "sha256-Y72QKrUD28uO76fBXtDyYXRi4gyqaUrR3DH9zBFOpDQ=",
      "url": "_framework/Microsoft.Extensions.FileSystemGlobbing.x7o86sid5q.wasm"
    },
    {
      "hash": "sha256-G4xmoaejMV//3A8kDCTMLiigNPoCZzAdfmjbLZVRt7I=",
      "url": "_framework/Microsoft.Extensions.Http.xxulsyw679.wasm"
    },
    {
      "hash": "sha256-apXa6mamrsCnV18rBxd6nKtEt6Os3DkJAqHgb1H+mb0=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.eqa55w08z6.wasm"
    },
    {
      "hash": "sha256-6UgMJoVZBfDdfzYR0aKVK6BWArxpXC1qiQDDjiXw/L4=",
      "url": "_framework/Microsoft.Extensions.Localization.bvn14pws96.wasm"
    },
    {
      "hash": "sha256-x75fCI52FTaQSWvHTbkCNwvRniOibids57Ms4mlqbBw=",
      "url": "_framework/Microsoft.Extensions.Logging.55cnwd7faq.wasm"
    },
    {
      "hash": "sha256-frW0eVbgnwZxpblg9SmkS2d3KpxvpRGjojNaFOWOiJY=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.eo9uhqlmdl.wasm"
    },
    {
      "hash": "sha256-TIjeTMxCkocDy6WSzOEZdvCetU5zZh3m3BD9N181xj4=",
      "url": "_framework/Microsoft.Extensions.Options.ConfigurationExtensions.wnne9gvp03.wasm"
    },
    {
      "hash": "sha256-5v4MbM60OAl1nLgi+l0D2LIGsfkjZ6phdti5C41O+Yc=",
      "url": "_framework/Microsoft.Extensions.Options.e68m42uu2c.wasm"
    },
    {
      "hash": "sha256-7gVOPPnRfQgYl33IV3fpE6Gk01IM7PN8dExEvpCk2+4=",
      "url": "_framework/Microsoft.Extensions.Primitives.ukouin6ngp.wasm"
    },
    {
      "hash": "sha256-BDqqFhjd3HgG1IWRDcIS3SXl+cTacqtRfMwtjOX1geE=",
      "url": "_framework/Microsoft.JSInterop.8z53h6bz8d.wasm"
    },
    {
      "hash": "sha256-sGms9Oai1ztzgfMsqBvmeKwa5ZyGWr/AEXr6thw0lso=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.8eb000j8w7.wasm"
    },
    {
      "hash": "sha256-z8IfMYhi9Pr3JQ+7QhzeU2dbrHsFifc0o8x2zxMaioE=",
      "url": "_framework/MudBlazor.lzzotdyjyj.wasm"
    },
    {
      "hash": "sha256-hGs2H48AS8zUFBq8xavWinkZiWKez7qRDKGqmJdGdt8=",
      "url": "_framework/System.Collections.0velyhhsrt.wasm"
    },
    {
      "hash": "sha256-6Yc0WepZ0eMr1IB9ujK9+QJx2gzQ4rOoGHCnFQh2zR0=",
      "url": "_framework/System.Collections.Concurrent.9wmkn45yqp.wasm"
    },
    {
      "hash": "sha256-sy1bbCScg5I1HhbOM2JvdSV/zlY4rryCTNwDwnLBfTk=",
      "url": "_framework/System.Collections.Immutable.f9eaz16jf8.wasm"
    },
    {
      "hash": "sha256-/EKw6AnuEFZq6ur2mRFE3Dh+MEjl6xRLIvYt7Sh/keo=",
      "url": "_framework/System.Collections.NonGeneric.w3nszrltmj.wasm"
    },
    {
      "hash": "sha256-LO5vNYO0iVBN5YTuyeuWO6GlGM5aKoHbUcRq4SdtvsU=",
      "url": "_framework/System.Collections.Specialized.grtqxp1kha.wasm"
    },
    {
      "hash": "sha256-cA1Ra8qBlL7J7GbAYnSXLcbf+LXlQbblOYTiuUFvMaA=",
      "url": "_framework/System.ComponentModel.Annotations.oqtkni67hd.wasm"
    },
    {
      "hash": "sha256-uQj/m4P/efRGU7/TIpq13nFa9Q3hKtKWvUqFL5WrXfU=",
      "url": "_framework/System.ComponentModel.Primitives.5xljb22z1k.wasm"
    },
    {
      "hash": "sha256-iqYYPCtVLBwf/7Teto+czHMLssZ4ke9d3ah4XpdPHSg=",
      "url": "_framework/System.ComponentModel.TypeConverter.a4rhjsa6zb.wasm"
    },
    {
      "hash": "sha256-9USOJqZ7jlkethsedYzZY95qWDtbmWEL6C3MOE2JWwg=",
      "url": "_framework/System.ComponentModel.teirny7gyp.wasm"
    },
    {
      "hash": "sha256-daFIEnj7oOESCjs7+2T1cSxQ0epkLGGBGqrjmXzEBeU=",
      "url": "_framework/System.Console.h57plfinyt.wasm"
    },
    {
      "hash": "sha256-Ci6gDcnJPAD2xw7w7dM9/wvQUVSqPrRzrRYQLCPtxDE=",
      "url": "_framework/System.Data.Common.it5ik0d6t7.wasm"
    },
    {
      "hash": "sha256-+aWbcl2Y++xDvNuH80j1wReZbitQ/MAFG7Tx3tA366U=",
      "url": "_framework/System.Diagnostics.Debug.xm426vc33p.wasm"
    },
    {
      "hash": "sha256-Rmn//zKYjvlY0uO8Pz5BldkYd6Q5o6JlTGTOtPoBl3Y=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.mo5qengx6p.wasm"
    },
    {
      "hash": "sha256-ifQOiDR7aCBN2F/GN0HT+XxY5GeNGuVCFHsIIAWG8L0=",
      "url": "_framework/System.Diagnostics.FileVersionInfo.1ik7l3vy0q.wasm"
    },
    {
      "hash": "sha256-XQpM+BswNRiYVvgA6S5uWGurOPEnER2HaCwwQMRYe44=",
      "url": "_framework/System.IO.Compression.ZipFile.n7p0itxedf.wasm"
    },
    {
      "hash": "sha256-UhMB2f3A7gk8jMh4A4S8qpG3FHI4+9wc48iveYY6ZvM=",
      "url": "_framework/System.IO.Compression.uls6hb8wz4.wasm"
    },
    {
      "hash": "sha256-49IkqpdpO4b6asYlXdhkjB22c8YIWEZnWjP2FSsnjmw=",
      "url": "_framework/System.IO.FileSystem.Watcher.layifoi3gt.wasm"
    },
    {
      "hash": "sha256-V5z9/XlJMVOFEDQ+R/mfLxmcykbKzh9+yhFeRdF4kdU=",
      "url": "_framework/System.IO.Pipelines.h68d94scrb.wasm"
    },
    {
      "hash": "sha256-KomS+XlwZXN9W0myJsBtSGhfY4BIP4XOvz19GGWpytg=",
      "url": "_framework/System.Linq.2awbdpyj40.wasm"
    },
    {
      "hash": "sha256-/DwkzU3lGGnsW7wRkNiVVwk2Zs5rU54V74Q3fag1JIc=",
      "url": "_framework/System.Linq.Expressions.4cl0vmco8h.wasm"
    },
    {
      "hash": "sha256-cE2p+IjZomIIAP0IMwx6iQlXdoHVyDZ5pz+90Q+qe1w=",
      "url": "_framework/System.Linq.Queryable.oafk7nagc3.wasm"
    },
    {
      "hash": "sha256-gGn6F5ClWegL+CBrzQr4QK26ILXBfpxaj5oaB55CFF4=",
      "url": "_framework/System.Memory.g42f14wylk.wasm"
    },
    {
      "hash": "sha256-YXKzz4LcOpx9sviu9i9fSjBbW9IKNEhpP2XMPzRqTqk=",
      "url": "_framework/System.Net.Http.Json.5vsdrtt1yr.wasm"
    },
    {
      "hash": "sha256-eO7dg2u0Oo6EuTWiRgQQoXgS3BrtYqFbnCQNhZ8pElc=",
      "url": "_framework/System.Net.Http.gqla9vgwp6.wasm"
    },
    {
      "hash": "sha256-RZU3+AurzUeBWgVjZalkA1jPlfRnehNr+R49gyYTuFI=",
      "url": "_framework/System.Net.Primitives.3uow9zd1kc.wasm"
    },
    {
      "hash": "sha256-DaFivkO9aCCFcGxEMQO8IPPlDml0JYyEQG5oagA7n5Q=",
      "url": "_framework/System.ObjectModel.777iasb6z6.wasm"
    },
    {
      "hash": "sha256-JsUSucHKAFTAGeHQ/iPDL7mbUSMKog7paUtxAv5kUbg=",
      "url": "_framework/System.Private.CoreLib.2yho2ycwyc.wasm"
    },
    {
      "hash": "sha256-iRzdy8DS7JxZdyvDx3LIo4UybEkdP+I8ReCgX26OSYY=",
      "url": "_framework/System.Private.Uri.5pcl1q225g.wasm"
    },
    {
      "hash": "sha256-38C0yV74XDp0+tc5lvpO/N+EX7B5ivLkTStfnZY4Unw=",
      "url": "_framework/System.Private.Xml.3rd1hds0gg.wasm"
    },
    {
      "hash": "sha256-JAdHsSnwf3yG/ODdYlI0dnbRDaFzeoSfb38Y/0zmp4c=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.gj6vy5z8xt.wasm"
    },
    {
      "hash": "sha256-IzPBiClwNoObraWZJ7zLKq/v7GvT87hwZ+Cq+YUX7Bo=",
      "url": "_framework/System.Reflection.Emit.touqnma2hc.wasm"
    },
    {
      "hash": "sha256-inIRd2+wD5LtXG+eSpR4dcWG7zgpjo4Nf+oEj+VjQb0=",
      "url": "_framework/System.Reflection.Primitives.e26nzzyiwq.wasm"
    },
    {
      "hash": "sha256-xhnod9khZW1/BlYxVWQKDHByXWcp+tdiUabM/1DRi0k=",
      "url": "_framework/System.Runtime.Extensions.ue36vl99ai.wasm"
    },
    {
      "hash": "sha256-r+LQmgoVdHgFKWJvUNAR7HQZAtSw+xvBIQ6siSPsBNM=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.f4ln4hfftw.wasm"
    },
    {
      "hash": "sha256-Ki9CIBGK1PxgT1lINYYrJXvIS+uhcVV7Po4GxFvD5SM=",
      "url": "_framework/System.Runtime.InteropServices.ebl1t4cqsb.wasm"
    },
    {
      "hash": "sha256-8sWQxyk0PLsOf9ztH+ahsZN6Eiey03vcN7obVobae7w=",
      "url": "_framework/System.Runtime.quqsvo7k8l.wasm"
    },
    {
      "hash": "sha256-ufiBGCIWmMuPMgoR4276ZlgsRQ/HISrcxnSP5zFSXA8=",
      "url": "_framework/System.Security.Claims.70s25m52mh.wasm"
    },
    {
      "hash": "sha256-AwLTpRtWRmZpOiG6sFkccu+mqXt2wy6MQSi5brtbYrg=",
      "url": "_framework/System.Security.Cryptography.3slzlpvyql.wasm"
    },
    {
      "hash": "sha256-q4wjDqVkS6LgR9lezi9Pqh4WGK/p1nCoHwNbcHmYcXw=",
      "url": "_framework/System.Text.Encodings.Web.delo57teov.wasm"
    },
    {
      "hash": "sha256-bRfiv62tNiKyO4xXU1ofK23MFHvL5XlhM/AWrRqKgr8=",
      "url": "_framework/System.Text.Json.73e5i8y2f3.wasm"
    },
    {
      "hash": "sha256-jyXUVF1oYQ4zTl5MhWndXS0z3+VrjnsquBEjb5Q+cPs=",
      "url": "_framework/System.Text.RegularExpressions.vcgrakwaja.wasm"
    },
    {
      "hash": "sha256-jYl84kvSfJiTwJs7uZbrMk+mxaMIhX5YjvW6XFbRhS0=",
      "url": "_framework/System.Threading.f9ul2acuy5.wasm"
    },
    {
      "hash": "sha256-H/1Y2PyUO8CHlwAZphwpuCrjIsV801O+qHR+YfGik/Q=",
      "url": "_framework/System.Web.HttpUtility.pamwqox0ti.wasm"
    },
    {
      "hash": "sha256-JR9uHwZeWzGLHbZhs4tvobv0QX0mykH6Dw/KbNqFbCA=",
      "url": "_framework/System.v3da086c8u.wasm"
    },
    {
      "hash": "sha256-eIZXP6Q7o4UEv0jJ0y/5JsXg5Z2gMjC021Ea4crJFNE=",
      "url": "_framework/UAParser.o84k4c0k2d.wasm"
    },
    {
      "hash": "sha256-UXSxxe0oTBV1YUush4krHYkOzlWoq3rstmO2+oRl6IY=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-/pcrNUZIFxvVrfML8zazMdEZ+IB0TdSKqJ6mAPvV+w4=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-d/tLlCD7xchKAM2qZHwRoTKgNe8VGhuayiqUvV6pGe8=",
      "url": "_framework/dotnet.native.3lge4v1pes.js"
    },
    {
      "hash": "sha256-qfuW3CD3gqBrH6nr80L6LEzZ2a3hVJcP+w3fM1p3uec=",
      "url": "_framework/dotnet.native.5lv7c9xsa5.wasm"
    },
    {
      "hash": "sha256-82FoDmY+LsehdN2u8aSGEutGEKXJHcYaSX/3zptbsCw=",
      "url": "_framework/dotnet.runtime.tsg4gsv2hg.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-2AouFyv+JeDV6Zimr2hCRYfurQMXN48FEQI+5YcQy3g=",
      "url": "_framework/netstandard.c7utrz9n54.wasm"
    },
    {
      "hash": "sha256-b8gj1/WVw9UaQt2Kgm7iyCdKIzT/8K0lSPboedW2OCo=",
      "url": "appsettings.json"
    },
    {
      "hash": "sha256-HtCCUh9Hkh//8U1OwcbD8epVEUdBvuI8wj1KtqMhNkI=",
      "url": "css/animate.css"
    },
    {
      "hash": "sha256-rv4BAsJnUCWOfONuZTlVtb+2FYJW2qnEj3LIa1IA2Ek=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-z8OR40MowJ8GgK6P89Y+hiJK5+cclzFHzLhFQLL92bg=",
      "url": "css/bootstrap/bootstrap.min.css"
    },
    {
      "hash": "sha256-gBwg2tmA0Ci2u54gMF1jNCVku6vznarkLS6D76htNNQ=",
      "url": "css/bootstrap/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-uKq+/i4Jrtg+GXn8LXBhVXydAooeHVelpvWM8Cas1mk=",
      "url": "css/flex-slider.css"
    },
    {
      "hash": "sha256-F8+WvdV0ZNDWfwMMOswImPiSFnfz1BPqA7NnTY7OOhc=",
      "url": "css/fontawesome.css"
    },
    {
      "hash": "sha256-vXLmt61jusWvSEMzyT9L+VKwAuQmTcOnFX/iG/oKIHI=",
      "url": "css/owl.css"
    },
    {
      "hash": "sha256-3tTGLQy+q9G1pFl4QHsaDJfJPlYc+JKwORwk+pdP1Zo=",
      "url": "css/templatemo-woox-travel.css"
    },
    {
      "hash": "sha256-HMFKsBDctq3cVqprigdLOxd/am4RxtIhg4EIByUtKrs=",
      "url": "dog_breeds.json"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-vauIgAkEfaNVcI1DVpYaB2I/SjzAgnRCuiLKjVQHElo=",
      "url": "img/Moto-club.svg"
    },
    {
      "hash": "sha256-M+xOz7N1bk2x+EGU7DPysbcYRJnNZD7bPSpSmnIiD5c=",
      "url": "img/bike.svg"
    },
    {
      "hash": "sha256-J8bI39xWe9Fm97VkS1xNnczlda+U8dJUm1n/2siVh3U=",
      "url": "img/icon-512.png"
    },
    {
      "hash": "sha256-hkh3BD3nyeWVXaZzRFP2udaAmJckS86cNYB4N+SgJp0=",
      "url": "img/logo.svg"
    },
    {
      "hash": "sha256-P8XwhAIN95lSGKa7Fllv1wlBJ8rM1ljTUOYmh0ZEyIw=",
      "url": "index.html"
    },
    {
      "hash": "sha256-XFoNzDuZrKcDMjAxFLHGaKjQy2RJB91tzWV51aMKYK4=",
      "url": "js/downloadSitemap.js"
    },
    {
      "hash": "sha256-VeO3LAKFTrja+3ZOVCIlwqUJCFxQnfpla/ufcsKcnl0=",
      "url": "js/generate-static.js"
    },
    {
      "hash": "sha256-gnAUy9aX09DSjkaFs3/o/HaiI78CeKXEYubSSefY9Go=",
      "url": "js/script.module.js"
    },
    {
      "hash": "sha256-GQVy2csA0hpAkbyORNPSufROzTcHWflSDHfXNykYFyw=",
      "url": "js/scroll.js"
    },
    {
      "hash": "sha256-wYqiAJi+ey2bFe+VEqeHFqYFFjEJaFKQiBp9862i6Lc=",
      "url": "js/ts/hello.js"
    },
    {
      "hash": "sha256-EXL6W5aQWYkZbBwO0ylSAK9SvjWXavRXVPdsJjw+c7w=",
      "url": "js/ts/hello.js.map"
    },
    {
      "hash": "sha256-uXkYE0c4sb+QKm4keqEnBhi5seCZ1TABmQd/9MZyhdg=",
      "url": "js/ts/scrollTestInTs.js"
    },
    {
      "hash": "sha256-ekrqHlYIIDtLBdCBSA4tr2uNFmOQXeB0FKsVK+qJ4oQ=",
      "url": "js/ts/scrollTestInTs.js.map"
    },
    {
      "hash": "sha256-/fROVxD7G2HmsOTAe+/is5mZn1/VMfTBkA3IeA1yAxk=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-Vs7AfF1yZLBMdl662PMDUIeGWsfaHl63PJOgcFSFRGY=",
      "url": "robots.txt"
    },
    {
      "hash": "sha256-bFOKqw5FbzFNuGp+UW8SdfNO/TQCT1bGGFz6nxgP9zU=",
      "url": "ts/hello.ts"
    },
    {
      "hash": "sha256-D67kXuqZUofIfLQEqX9zfAOqTFvoTnx6IRI6HK68CGM=",
      "url": "ts/scrollTestInTs.ts"
    }
  ]
};
